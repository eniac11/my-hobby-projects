import os
from pathlib import Path, WindowsPath


os.environ["PYTHONPATH"] = str(Path("../tools").resolve().absolute()) + ";" + os.environ["PYTHONPATH"]
