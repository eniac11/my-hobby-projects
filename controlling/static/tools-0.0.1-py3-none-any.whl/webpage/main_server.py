import webpage
import flask
from flask import request

from tools.htmls import *
from tools.main import ipc_handler
from tools.ipc.common import Side

app = flask.Flask(__name__)

ipc_handler.set_side(Side.SERVER)


@app.route("/", methods=["POST"])
def test():
    if request.method == "POST":
        ipc_handler.receive([request.data])
        ipc_handler.handle()
    return ""



@app.route("/macros")
def macros():
    return macro_page