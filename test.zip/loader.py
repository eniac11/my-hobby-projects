import os

from pathlib import Path

path = Path("tools")

for node in Path('.').iterdir():
    if node.is_file():
        with node.open() as f:
            line = f.readline()
            if '__future__' in line:
                line = f.readline()
            if line.startswith('# '):
                line = line.replace('# ', '').strip()

                p = Path(line)

                if 'tools/' not in line:
                    p = path / line

                p.parents[0].mkdir(parents=True, exist_ok=True)

                node.rename(p)

import main
