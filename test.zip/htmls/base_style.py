# htmls/base_style.py
from .styles import *

#
# style_sheet = StyleSheet(body=StyleContainer(
#     styles={
#         **add_style_def('pre', [], {
#             **add_style_def('has(>code)', [
#                 Style('background', 'gray')
#             ])
#         })
#     },
#     classes={
#         **add_style_def('internal_link', [
#             Style("color", "black")
#         ], {
#                             **add_style_def('hover', [
#                                 Style('color', 'gray')
#                             ])
#                         }),
#
#     })
# )


internal_link = (
    class_('internal_link')
    .style('color', 'black')
    .pseudo('hover')
    .style('color', 'gray')
)

style_container = StyleContainer()
style_container.add(
    style('pre')
    .pseudo('has')
    .child('code')
    .style('background', 'gray')
)
style_container.add(internal_link)

style_sheet = StyleSheet(style_container)
