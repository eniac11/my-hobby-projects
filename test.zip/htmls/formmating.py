from __future__ import annotations
# htmls/formmating.py

from typing import Optional

from tools.htmls.utils import Transform


class Slot(Transform):

    def __init__(self, name: Optional[str] = None):
        super().__init__()
        self.name = name
        self.filled = False

    def replace(self, elem):
        self.elem_ = elem
        self.filled = True

    def __call__(self):
        return SlotValue(self)


class SlotValue:
    def __init__(self, slot: Slot):
        self.slot: Slot = slot

    def __getattr__(self, item):
        if self.slot.filled:
            return getattr(self.slot.elem_, item)
        return DelayedValue(self, item)

class DelayedValue:

    def __init__(self, value: Slot, attr: str, delayed_slot_value=None):
        self.slot: Slot = value
        self.attr = attr
        self.args = None
        self.kwargs = None
        self.delayed_slot_value = delayed_slot_value
        self.func = False

    def __call__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        self.func = True

        return self

    def __getattr__(self, item):
        if self.slot.filled:

            return getattr(self.slot, item)
        return DelayedValue(self.slot, item, self)

    def __get__(self):
        if self.func:
            return getattr(self.slot, self.attr)(*self.args, **self.kwargs)
        return getattr(self.slot, self.attr)



def slot(name: str = None):
    return Slot(name)


def has_slot(element):
    slots = element.internal_get_representation_blocks(Slot)
    if len(slots) > 0:
        return True
    return False


def set_slot(slotted_element, replace_elem, name: Optional[str] = None):
    slots = slotted_element.internal_get_representation_blocks(Slot)
    if len(slots) == 1:
        slots[0].replace(replace_elem)
        return
    for slot_ in slots:
        slot_: Slot
        if name is not None and slot_.name == name:
            slot_.replace(replace_elem)
