# htmls/forms/__init__.py

from tools.htmls import Transform, has_slot, set_slot, slot
from tools.htmls.html import *

from tools.htmls.html_elements import *
from typing import Any


class FormField(Transform):

    def __init__(self, type_: str, name: str, widget: Element = None, default_value: Any = None, required=False):
        input_elem = createInput(type_, name, value=default_value, required=required)
        widget = self.check_slot(widget, input_elem)
        super().__init__(widget)
        self.type_ = type_
        self.name = name
        self.value = default_value
        self.required = required
        self.elem_: Element = self.elem_

    def check_slot(self, widget, default=None):
        if widget is None:
            widget = default
        else:
            if has_slot(widget):
                set_slot(widget, default)
        return widget


class Form(Element):
    def __init__(self, name: str, url: str, method: HTTPMethod, **kwargs):
        super().__init__('form', id=name, action=url, method=method, **kwargs)
        self.method = method
        self.url = url
        self.fields: list[FormField] = []

    def add_field(self, field):
        self.fields.append(field)
        self.children.append(field)

    def __getitem__(self, name):
        for field in self.fields:
            if field.name == name:
                return field
        raise KeyError("No key: " + name)


class ComboboxField(FormField):

    def __init__(self, name: str, items: list[tuple[str, str]], default_index: int = 0, required=False, **kwargs):
        widget = create_element("select", children=[
            create_element('option', value=index, children=[name]) for index, name in items
        ], name_=name, required=required, **kwargs)
        super().__init__('combo', name, widget, required)


def createInput(type_, name, /, id_=None, *, value=None, **kwargs):
    return Element("input", name_=name, type=type_, value=value, id=(name if id_ is None else id_), **kwargs)


def create_label(for_: Element, label: str, **kwargs):
    return Element('label', for_=for_.get_id(), inner=label, **kwargs)


def labeled_elem(label, *, reverse=False):
    if reverse:
        return create_div([(s := slot()), create_label(for_=s(), label=label)])
    return create_div([create_label(for_=(s := slot())(), label=label), s])


def create_radio(name, /, id_=None, *, value=None, **kwargs):
    return createInput('radio', name, id_, value=value, **kwargs)


def create_label_radio_group(label_, radios, *, new_line=False):
    for label, radio in radios:
        yield labeled_elem(label, create_radio(label_, id_=radio, value=label), reverse=True)
        if new_line:
            yield [create_breakline()]
