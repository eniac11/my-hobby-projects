# htmls/element_formating.py
import copy
from functools import partial

__all__ = ['transform_text', 'title', 'upper', 'bold', 'italic', 'underline', 'hr']

from tools.htmls.html import *
from tools.htmls.html import DelayedElementTransform
from tools.htmls.utils import *


def transform_text(elem: Element | TextBlock | str, func):
    transformer = elem

    if type(transformer) in [TextBlock, str]:
        transformer = transform_block_to_text_block(elem)
        transformer.elem_ = func(transformer.elem_)
    if type(transformer) == Element:
        text_blocks = transformer.internal_get_representation_blocks(TextBlock)

        for text_block in text_blocks:
            text_block.elem_ = func(text_block.elem_)
    return transformer


def title(elem):
    transformer = copy.deepcopy(elem)

    return DelayedElementTransform(transformer, partial(transform_text, func=str.title))


def upper(elem):
    transformer = copy.deepcopy(elem)
    return DelayedElementTransform(transformer, partial(transform_text, func=str.upper))


def bold(inner, **kwargs):
    return Element('b', inner=inner, **kwargs)


def italic(inner, **kwargs):
    return Element('i', inner=inner, **kwargs)


def underline(inner, **kwargs):
    return Element('u', inner=inner, **kwargs)


def hr():
    return Element('hr', single=True)
