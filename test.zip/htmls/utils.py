from __future__ import annotations
# htmls/utils.py
import itertools
import uuid
from typing import Any

__all__ = ['equatify', 'unpack', 'Transform', 'TextBlock', 'DelayedTransform', 'transform_block_to_text_block',
           'transform', 'process_variable_underscore']


def process_variable_underscore(val: str):
    val = val.strip("_")
    return val.replace("_", "-")


def equatify(d):
    s = ""
    for key, val in d.items():
        if type(val) == bool:
            if val:
                s += process_variable_underscore(key) + " "
        else:
            if val is not None:
                if type(val) == str and len(val) == 0:
                    continue
                s += f'{process_variable_underscore(key)}="{val}" '
    return s[:-1]


def unpack(iterable):
    return list(itertools.chain.from_iterable(iterable))


class Transform:
    def __init__(self, elem=None):
        self.elem_ = elem

    def __transform__(self):

        return self.elem_

    def replace(self, replacement):
        self.__dict__ = replacement.__dict__

class ListTransform(Transform):
    pass


class TextBlock(Transform):

    def __init__(self, text: str):
        super().__init__(text)
        self.id = uuid.uuid4()
        self.elem_: str = self.elem_


def transform_block_to_text_block(values: list[Any] | str):
    if type(values) == TextBlock:
        return values
    if type(values) == str:
        return TextBlock(values)

    if type(values) in [list, tuple]:
        for i, value in enumerate(values):
            if type(value) == str:
                values[i] = TextBlock(value)
    return values


class DelayedTransform(Transform):

    def __init__(self, elem, func):
        super().__init__(elem)
        self.func = func

    def __transform__(self):
        system = transform(self.elem_)
        # print("s", system)
        return self.func(system)


def transform(transformer):
    # print("f", transformer, type(transformer))
    if issubclass(transformer.__class__, Transform):

        attr = getattr(transformer, '__transform__')
        # if type(transformer) == TextBlock:
        #     print(transformer.elem, attr, attr())

        if (test := attr()) is None:
            return ''
        return transform(test)
    return transformer
