# htmls/config.py
from .base_style import style_sheet
from .utils import *

#print(str(transform(style_sheet)))
