# htmls/javascript/api.py
from .javascript import *

__all__ = ['console', 'JSON', 'fetch', 'document']

from .. import HTTPMethod

console = MappedClass('console', ['log'])
JSON = MappedClass('JSON', ['stringify'])
document = MappedClass('document', ['getElementById'])

_fetch = Function('fetch', ['url', 'data'], [])


def single_quote(string):
    return "'" + string + "'"


def js_dict(**kwargs):
    s = "{"
    for key, value in kwargs.items():
        s += single_quote(key) + ":"
        if type(value) == FunctionCall:
            value: FunctionCall


def fetch(url, method: HTTPMethod, type_: ContentTypes, data):
    data = {'method': method.value, 'headers': {'Content-Type': type_.value},
            'body': JSON.stringify([data]).call(True).code}

    return _fetch([single_quote(url), data], True)
