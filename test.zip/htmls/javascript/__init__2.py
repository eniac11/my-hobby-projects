# htmls/javascript/__init__.py
from .javascript import *
