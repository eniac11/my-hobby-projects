# htmls/html_elements.py
from .html import *

__all__ = ['create_div', 'create_breakline', 'create_element', 'create_button', 'create_image', 'create_p',
           'create_header','create_list_item', 'create_span']


def create_div(children, **kwargs):
    return Element('div', children=children, **kwargs)


def create_breakline():
    return Element('br', single=True)


# def create_form_label(inp: Element, label: str,newline=False, children=None):
# label_elem = Element('label', for_=inp.name, children=children)
# label_elem.inner = label
# if newline:
# return create_div(children=[label_elem, create_breakline(), inp])

# return create_div(children=[label_elem, inp])


def create_element(tag, /, inner=None, **kwargs):
    return Element(tag, inner=inner, **kwargs)

def create_span(**kwargs):
    return create_element('span', **kwargs)


def create_p(inner=None, **kwargs):
    return create_element('p', inner, **kwargs)


def create_header(text, *, level=1, **kwargs):
    return create_element("h" + str(level), inner=text, **kwargs)


def create_image(src, **kwargs):
    return Element('img', src=src, single=True, **kwargs)


def create_button(name, *, onclick=None, **kwargs):
    return Element('button', inner=name, onclick=onclick, **kwargs)


def create_list_item(**kwargs):
    return Element('li', **kwargs)
