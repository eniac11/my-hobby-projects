# htmls/layout.py
from .html import *
from .utils import *
from .html_elements import *
from .styles import *

import copy


class Layout(Transform):

    def __init__(self):
        self.elem = None
        self.styles = None


def flex_item(child: Element, grow=None):
    child = copy.deepcopy(child)
    child.styles.append(Style('flex', grow))
    return child


def flex(child: Element, direction="row"):
    child = copy.deepcopy(child)
    child.styles.append(Style('display', 'flex'))
    child.styles.append(Style('flex-direction', direction))
    return child

def center(elem, **kwargs):
    return create_element('center', children=[elem], **kwargs)