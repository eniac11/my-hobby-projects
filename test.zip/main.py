from tools.htmls.html_elements import create_button

button = create_button('reload')
print(str(button))





# print(dir(window.FileSystemEntry.filesystem.root))
